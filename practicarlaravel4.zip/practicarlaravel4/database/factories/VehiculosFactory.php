<?php

namespace Database\Factories;

use App\Models\Vehiculos;
use Illuminate\Database\Eloquent\Factories\Factory;

class VehiculosFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Vehiculos::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            'tipo' => $this->faker->randomElement(['Coche','Barco','Camion','Moto', 'Avion']),
            'matricula' => $this->faker->name(),
            'precio' => rand(1000,10000000),
            'descripcion' => $this->faker->paragraph(),
            'valoracion' => rand(1,10),
        ];
    }
}
