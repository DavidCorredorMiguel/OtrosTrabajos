<?php

namespace Database\Factories;

use App\Models\Casas;
use Illuminate\Database\Eloquent\Factories\Factory;

class CasasFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Casas::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            'tipo' => $this->faker->randomElement(['Mansion','Apartamento','Chalet','Casa De Campo']),
            'localidad' => $this->faker->name(),
            'precio' => rand(10000,10000000),
            'descripcion' => $this->faker->paragraph(),
            'valoracion' => rand(1,10),
        ];
    }
}
