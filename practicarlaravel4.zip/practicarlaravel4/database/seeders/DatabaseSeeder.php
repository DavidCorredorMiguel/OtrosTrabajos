<?php

namespace Database\Seeders;

use App\Models\Casas;
use App\Models\Juegos;
use App\Models\Vehiculos;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Casas::factory(30)->create();
        Vehiculos::factory(30)->create();
        Juegos::factory(30)->create();
    }
}
