
<?php $__env->startSection('titulo', 'home'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Lista Casas</h1>
    <a href="<?php echo e(route('casas.create')); ?>">Crear Casa</a>
    <ul>
        <?php $__currentLoopData = $casas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('casas.show', $casa)); ?>"><?php echo e($casa->name); ?> (<?php echo e($casa->tipo); ?>) Precio:
                <?php echo e($casa->precio); ?> €</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($casas->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel4\resources\views/casas/index.blade.php ENDPATH**/ ?>