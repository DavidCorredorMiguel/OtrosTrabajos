
<?php $__env->startSection('titulo', 'show'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Datos Casa</h1>
    <a href="<?php echo e(route('casas.edit', $casa)); ?>">Editar Casa</a>
    <p><strong>Nombre: </strong><?php echo e($casa->name); ?></p>
    <p><strong>Tipo: </strong><?php echo e($casa->tipo); ?></p>
    <p><strong>Localidad: </strong><?php echo e($casa->localidad); ?></p>
    <p><strong>Precio: </strong><?php echo e($casa->precio); ?></p>
    <p><strong>Descripcion: </strong><?php echo e($casa->descripcion); ?></p>
    <p><strong>Valoracion: </strong><?php echo e($casa->valoracion); ?></p>
    <form action="<?php echo e(route('casas.destroy', $casa)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <input type="submit" value="Borrar">
    </form>
    <br><a href="<?php echo e(route('casas.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel4\resources\views/casas/show.blade.php ENDPATH**/ ?>