
<?php $__env->startSection('titulo', 'index'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Lista Juegos</h1>
    <a href="<?php echo e(route('juegos.create')); ?>">Crear Juego</a>
    <ul>
        <?php $__currentLoopData = $juegos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('juegos.show', $juego)); ?>"><?php echo e($juego->name); ?> (<?php echo e($juego->plataforma); ?>)</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($juegos->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel4\resources\views/juegos/index.blade.php ENDPATH**/ ?>