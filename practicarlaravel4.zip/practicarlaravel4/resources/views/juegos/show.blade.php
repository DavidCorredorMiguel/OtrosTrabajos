@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Datos Juego</h1>
    <a href="{{ route('juegos.edit', $juego) }}">Editar Juego</a>
    <p><strong>Nombre: </strong>{{ $juego->name }}</p>
    <p><strong>Plataforma: </strong>{{ $juego->plataforma }}</p>
    <p><strong>Compania: </strong>{{ $juego->compania }}</p>
    <p><strong>Genero: </strong>{{ $juego->genero }}</p>
    <p><strong>Descripcion: </strong>{{ $juego->descripcion }}</p>
    <p><strong>Valoracion: </strong>{{ $juego->valoracion }}</p>
    <form action="{{ route('juegos.destroy', $juego) }}" method="post">
        @csrf
        @method('delete')
        <input type="submit" value="Borrar">
    </form>
    <br><a href="{{ route('juegos.index') }}">Volver</a>
@endsection