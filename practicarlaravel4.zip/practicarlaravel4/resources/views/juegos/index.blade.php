@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Juegos</h1>
    <a href="{{ route('juegos.create') }}">Crear Juego</a>
    <ul>
        @foreach ($juegos as $juego)
            <li><a href="{{ route('juegos.show', $juego) }}">{{ $juego->name }} ({{ $juego->plataforma }})</a></li>
        @endforeach
    </ul>
    {{ $juegos->links() }}
@endsection