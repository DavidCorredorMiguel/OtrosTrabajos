@extends('layouts.plantilla')
@section('titulo', 'edit')
@section('contenido')
    <h1>Editar Casa</h1>
    <form action="{{ route('casas.update', $casa) }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $casa->name) }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Tipo: </label>
        <input type="text" name="tipo" value="{{ old('tipo', $casa->tipo) }}">
        @error('tipo')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Localidad: </label>
        <input type="text" name="localidad" value="{{ old('localidad', $casa->localidad) }}">
        @error('localidad')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Precio: </label>
        <input type="text" name="precio" value="{{ old('precio', $casa->precio) }}">
        @error('anoinicio')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" 
        cols="30" rows="10">{{ old('descripcion', $casa->descripcion) }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion', $casa->valoracion) }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('casas.index') }}">Volver</a>
@endsection