@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Casas</h1>
    <a href="{{ route('casas.create') }}">Crear Casa</a>
    <ul>
        @foreach ($casas as $casa)
            <li><a href="{{ route('casas.show', $casa) }}">{{ $casa->name }} ({{ $casa->tipo }}) Precio:
                {{ $casa->precio }} €</a></li>
        @endforeach
    </ul>
    {{ $casas->links() }}
@endsection