@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Datos Casa</h1>
    <a href="{{ route('casas.edit', $casa) }}">Editar Casa</a>
    <p><strong>Nombre: </strong>{{ $casa->name }}</p>
    <p><strong>Tipo: </strong>{{ $casa->tipo }}</p>
    <p><strong>Localidad: </strong>{{ $casa->localidad }}</p>
    <p><strong>Precio: </strong>{{ $casa->precio }}</p>
    <p><strong>Descripcion: </strong>{{ $casa->descripcion }}</p>
    <p><strong>Valoracion: </strong>{{ $casa->valoracion }}</p>
    <form action="{{ route('casas.destroy', $casa) }}" method="post">
        @csrf
        @method('delete')
        <input type="submit" value="Borrar">
    </form>
    <br><a href="{{ route('casas.index') }}">Volver</a>
@endsection