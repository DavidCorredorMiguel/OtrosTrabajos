@extends('layouts.plantilla')
@section('titulo', 'create')
@section('contenido')
    <h1>Crea Vehiculo</h1>
    <form action="{{ route('vehiculos.store') }}" method="post">
        @csrf
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name') }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Tipo: </label>
        <input type="text" name="tipo" value="{{ old('tipo') }}">
        @error('tipo')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Matricula: </label>
        <input type="text" name="matricula" value="{{ old('matricula') }}">
        @error('matricula')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Precio: </label>
        <input type="text" name="precio" value="{{ old('precio') }}">
        @error('precio')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" 
        cols="30" rows="10">{{ old('descripcion') }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion') }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Crear">
    </form>
    <br><a href="{{ route('vehiculos.index') }}">Volver</a>
@endsection