@extends('layouts.plantilla')
@section('titulo', 'create')
@section('contenido')
    <h1>Crea Vehiculo</h1>
    <form action="{{ route('vehiculos.update', $vehiculo) }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $vehiculo->name) }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Tipo: </label>
        <input type="text" name="tipo" value="{{ old('tipo', $vehiculo->tipo) }}">
        @error('tipo')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Matricula: </label>
        <input type="text" name="matricula" value="{{ old('matricula', $vehiculo->matricula) }}">
        @error('matricula')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Precio: </label>
        <input type="text" name="precio" value="{{ old('precio', $vehiculo->precio) }}">
        @error('precio')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" 
        cols="30" rows="10">{{ old('descripcion', $vehiculo->descripcion) }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion', $vehiculo->valoracion) }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('vehiculos.index') }}">Volver</a>
@endsection