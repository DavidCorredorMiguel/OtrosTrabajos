@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Vehiculos</h1>
    <a href="{{ route('vehiculos.create') }}">Crear Vehiculo</a>
    <ul>
        @foreach ($vehiculos as $vehiculo)
            <li><a href="{{ route('vehiculos.show', $vehiculo) }}">{{ $vehiculo->name }} 
                ({{ $vehiculo->tipo }}) Precio: {{ $vehiculo->precio }} €</a></li>
        @endforeach
    </ul>
    {{ $vehiculos->links() }}
@endsection