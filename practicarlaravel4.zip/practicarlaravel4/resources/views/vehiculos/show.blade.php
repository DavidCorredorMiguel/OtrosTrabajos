@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Datos Vehiculo</h1>
    <a href="{{ route('vehiculos.edit', $vehiculo) }}">Editar Vehiculo</a>
    <p><strong>Nombre: </strong>{{ $vehiculo->name }}</p>
    <p><strong>Tipo: </strong>{{ $vehiculo->tipo }}</p>
    <p><strong>Matricula: </strong>{{ $vehiculo->matricula }}</p>
    <p><strong>Precio: </strong>{{ $vehiculo->precio }}</p>
    <p><strong>Descripcion: </strong>{{ $vehiculo->descripcion }}</p>
    <p><strong>Valoracion: </strong>{{ $vehiculo->valoracion }}</p>
    <form action="{{ route('vehiculos.destroy', $vehiculo) }}" method="post">
        @csrf
        @method('delete')
        <input type="submit" value="Borrar">
    </form>
    <br><a href="{{ route('vehiculos.index') }}">Volver</a>
@endsection