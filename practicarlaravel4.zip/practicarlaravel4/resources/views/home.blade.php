@extends('layouts.plantilla')
@section('titulo', 'home')
@section('contenido')
    <h1>Bienvenido</h1>
    <a href="{{ route('casas.index') }}">Casas</a>
    <br><br><a href="{{ route('vehiculos.index') }}">Vehiculos</a>
    <br><br><a href="{{ route('juegos.index') }}">Juegos</a>
@endsection