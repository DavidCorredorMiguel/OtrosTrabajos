
<?php $__env->startSection('titulo', 'show'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Detalles Usuario</h1>
    <a href="<?php echo e(route('usuarios.edit', $usuario)); ?>">Editar Usuario</a>
    <p><strong>Nombre: </strong> <?php echo e($usuario->name); ?></p>
    <p><strong>Email: </strong> <?php echo e($usuario->email); ?></p>
    <p><strong>Password: </strong> <?php echo e($usuario->password); ?></p>
    <a href="<?php echo e(route('usuarios.index')); ?>">Volver</a>
    <form action="<?php echo e(route('usuarios.destroy', $usuario)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <br><input type="submit" value="Eliminar">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\usuarios\resources\views/usuarios/show.blade.php ENDPATH**/ ?>