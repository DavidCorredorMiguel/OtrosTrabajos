@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Usuarios</h1>
    <a href="{{ route('usuarios.create') }}">Crear Usuario</a>
    <ul>
        @foreach ($usuarios as $usuario)
            <li><a href="{{ route('usuarios.show', $usuario) }}">{{ $usuario->name }}</a></li>
        @endforeach
    </ul>
    {{ $usuarios->links() }}
@endsection