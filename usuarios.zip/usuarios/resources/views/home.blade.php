@extends('layouts.plantilla')
@section('titulo', 'home')
@section('contenido')
    <h1>Bienvenido</h1>
    <a href="{{ route('usuarios.index') }}">Usuarios</a>
@endsection