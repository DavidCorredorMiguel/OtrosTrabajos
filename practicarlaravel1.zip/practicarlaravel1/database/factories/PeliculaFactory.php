<?php

namespace Database\Factories;

use App\Models\Pelicula;
use Illuminate\Database\Eloquent\Factories\Factory;

class PeliculaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Pelicula::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            'genero' => $this->faker->randomElement(['Accion','Anime','Animacion','Ciencia Ficcion',
            'Comedia','Drama','Terror','Thriller']),
            'director' => $this->faker->name(),
            'descripcion' => $this->faker->paragraph(),
            'ano' => rand(1900,2025),
            'valoracion' => rand(1,10),
        ];
    }
}
