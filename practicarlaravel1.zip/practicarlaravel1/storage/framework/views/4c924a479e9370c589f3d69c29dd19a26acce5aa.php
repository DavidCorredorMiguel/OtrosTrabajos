
<?php $__env->startSection('titulo', 'index'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Lista Usuarios</h1>
    <a href="<?php echo e(route('usuarios.create')); ?>">Crear Usuario</a>
    <ul>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('usuarios.show', $usuario)); ?>"><?php echo e($usuario->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($usuarios->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\prlaravel1\resources\views/usuarios/index.blade.php ENDPATH**/ ?>