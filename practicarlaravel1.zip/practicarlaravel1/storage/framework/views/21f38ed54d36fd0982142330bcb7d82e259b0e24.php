<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
    <style>
        body{
            background-color: orange;
        }

        h1, strong{
            color: white;
            text-decoration: underline;
        }

        input{
            padding: 10px;
            background-color: blue;
            color: yellow;
        }

        p{
            color: blue;
        }

        a{
            color: red;
        }
    </style>
</head>
<body>
    <?php echo $__env->yieldContent('contenido'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel1\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>