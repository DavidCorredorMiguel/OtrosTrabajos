
<?php $__env->startSection('titulo', 'show'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Datos Pelicula</h1>
    <a href="<?php echo e(route('peliculas.edit', $pelicula)); ?>">Editar Usuario</a>
    <p><strong>Nombre: </strong><?php echo e($pelicula->name); ?></p>
    <p><strong>Genero: </strong><?php echo e($pelicula->genero); ?></p>
    <p><strong>Director: </strong><?php echo e($pelicula->director); ?></p>
    <p><strong>Descripcion: </strong><?php echo e($pelicula->descripcion); ?></p>
    <p><strong>Año: </strong><?php echo e($pelicula->ano); ?></p>
    <p><strong>Valoracion: </strong><?php echo e($pelicula->valoracion); ?></p>
    <a href="<?php echo e(route('peliculas.index')); ?>">Volver</a>
    <form action="<?php echo e(route('peliculas.destroy', $pelicula)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <br><input type="submit" value="Borrar">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel1\resources\views/peliculas/show.blade.php ENDPATH**/ ?>