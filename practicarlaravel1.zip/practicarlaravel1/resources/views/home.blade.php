@extends('layouts.plantilla')
@section('titulo', 'home')
@section('contenido')
    <h1>Bienvenido</h1>
    <a href="{{ route('usuarios.index') }}">Usuarios</a>
    <br><br><a href="{{ route('peliculas.index') }}">Peliculas</a>
@endsection