@extends('layouts.plantilla')
@section('titulo', 'create')
@section('contenido')
    <h1>Crear Pelicula</h1>
    <form action="{{ route('peliculas.store') }}" method="post">
        @csrf
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name') }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Genero: </label>
        <input type="text" name="genero" value="{{ old('genero') }}">
        @error('genero')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Director: </label>
        <input type="text" name="director" value="{{ old('director') }}">
        @error('director')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" cols="30" rows="10">{{ old('descripcion') }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Año: </label>
        <input type="text" name="ano" value="{{ old('ano') }}">
        @error('ano')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion') }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Crear">
    </form>
    <br><a href="{{ route('peliculas.index') }}">Volver</a>
@endsection