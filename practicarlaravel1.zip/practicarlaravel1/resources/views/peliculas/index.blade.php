@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Peliculas</h1>
    <a href="{{ route('peliculas.create') }}">Crear Pelicula</a>
    <ul>
        @foreach ($peliculas as $pelicula)
            <li><a href="{{ route('peliculas.show', $pelicula) }}">{{ $pelicula->name }} ({{ $pelicula->ano }})</a></li>
        @endforeach
    </ul>
    {{ $peliculas->links() }}
@endsection