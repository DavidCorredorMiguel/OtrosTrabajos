@extends('layouts.plantilla')
@section('titulo', 'edit')
@section('contenido')
    <h1>Editar Usuario</h1>
    <form action="{{ route('peliculas.update', $pelicula) }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $pelicula->name) }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Genero: </label>
        <input type="text" name="genero" value="{{ old('genero', $pelicula->genero) }}">
        @error('genero')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Director: </label>
        <input type="text" name="director" value="{{ old('director', $pelicula->director) }}">
        @error('director')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" cols="30" rows="10">{{ old('descripcion', $pelicula->descripcion) }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Año: </label>
        <input type="text" name="ano" value="{{ old('ano', $pelicula->ano) }}">
        @error('ano')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion', $pelicula->valoracion) }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('peliculas.index') }}">Volver</a>
@endsection