@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Datos Pelicula</h1>
    <a href="{{ route('peliculas.edit', $pelicula) }}">Editar Usuario</a>
    <p><strong>Nombre: </strong>{{ $pelicula->name }}</p>
    <p><strong>Genero: </strong>{{ $pelicula->genero }}</p>
    <p><strong>Director: </strong>{{ $pelicula->director }}</p>
    <p><strong>Descripcion: </strong>{{ $pelicula->descripcion }}</p>
    <p><strong>Año: </strong>{{ $pelicula->ano }}</p>
    <p><strong>Valoracion: </strong>{{ $pelicula->valoracion }}</p>
    <a href="{{ route('peliculas.index') }}">Volver</a>
    <form action="{{ route('peliculas.destroy', $pelicula) }}" method="post">
        @csrf
        @method('delete')
        <br><input type="submit" value="Borrar">
    </form>
@endsection