@extends('layouts.plantilla')
@section('titulo', 'edit')
@section('contenido')
    <h1>Editar Usuario</h1>
    <form action="{{ route('usuarios.update', $usuario) }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $usuario->name) }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Email: </label>
        <input type="text" name="email" value="{{ old('email', $usuario->email) }}">
        @error('email')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Password: </label>
        <input type="text" name="password" value="{{ old('password', $usuario->password) }}">
        @error('password')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Edad: </label>
        <input type="text" name="edad" value="{{ old('edad', $usuario->edad) }}">
        @error('edad')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('usuarios.index') }}">Volver</a>
@endsection