@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Datos Usuario</h1>
    <a href="{{ route('usuarios.edit', $usuario) }}">Editar Usuario</a>
    <p><strong>Nombre: </strong>{{ $usuario->name }}</p>
    <p><strong>Email: </strong>{{ $usuario->email }}</p>
    <p><strong>Password: </strong>{{ $usuario->password }}</p>
    <a href="{{ route('usuarios.index') }}">Volver</a>
    <form action="{{ route('usuarios.destroy', $usuario) }}" method="post">
        @csrf
        @method('delete')
        <br><input type="submit" value="Borrar">
    </form>
@endsection