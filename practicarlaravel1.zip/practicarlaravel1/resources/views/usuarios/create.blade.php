@extends('layouts.plantilla')
@section('titulo', 'create')
@section('contenido')
    <h1>Crear Usuario</h1>
    <form action="{{ route('usuarios.store') }}" method="post">
        @csrf
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name') }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Email: </label>
        <input type="text" name="email" value="{{ old('email') }}">
        @error('email')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Password: </label>
        <input type="text" name="password" value="{{ old('password') }}">
        @error('password')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Edad: </label>
        <input type="text" name="edad" value="{{ old('edad') }}">
        @error('edad')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Crear">
    </form>
    <br><a href="{{ route('usuarios.index') }}">Volver</a>
@endsection