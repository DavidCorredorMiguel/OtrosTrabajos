
<?php $__env->startSection('titulo', 'index'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Lista Frutas</h1>
    <a href="<?php echo e(route('frutas.create')); ?>">Crear Frutas</a>
    <ul>
        <?php $__currentLoopData = $frutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('frutas.show', $fruta)); ?>"><?php echo e($fruta->name); ?> (<?php echo e($fruta->tipo); ?>)</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($frutas->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel2\resources\views/frutas/index.blade.php ENDPATH**/ ?>