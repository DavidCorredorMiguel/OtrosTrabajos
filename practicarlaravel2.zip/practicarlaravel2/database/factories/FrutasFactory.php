<?php

namespace Database\Factories;

use App\Models\Frutas;
use Illuminate\Database\Eloquent\Factories\Factory;

class FrutasFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Frutas::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            'tipo' => $this->faker->randomElement(['Logia','Zoan','Paramecia','Desconocido']),
            'descripcion' => $this->faker->paragraph(),
            'valoracion' => rand(1,10),
        ];
    }
}
