@extends('layouts.plantilla')
@section('titulo', 'edit')
@section('contenido')
    <h1>Bienvenido</h1>
    <form action="{{ route('juegos.update', $juego) }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $juego->name) }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Compania: </label>
        <input type="text" name="compania" value="{{ old('compania', $juego->compania) }}">
        @error('compania')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Genero: </label>
        <input type="text" name="genero" value="{{ old('genero', $juego->genero) }}">
        @error('genero')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" 
        cols="30" rows="10">{{ old('descripcion', $juego->descripcion) }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion', $juego->valoracion) }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('juegos.index') }}">Volver</a>
@endsection