@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Frutas</h1>
    <a href="{{ route('frutas.create') }}">Crear Frutas</a>
    <ul>
        @foreach ($frutas as $fruta)
            <li><a href="{{ route('frutas.show', $fruta) }}">{{ $fruta->name }} ({{ $fruta->tipo }})</a></li>
        @endforeach
    </ul>
    {{ $frutas->links() }}
@endsection