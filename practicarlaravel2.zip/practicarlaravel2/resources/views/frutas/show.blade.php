@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Detalles Fruta</h1>
    <a href="{{ route('frutas.edit', $fruta) }}">Editar Fruta</a>
    <p><strong>Nombre: </strong>{{ $fruta->name }}</p>
    <p><strong>Tipo: </strong>{{ $fruta->tipo }}</p>
    <p><strong>Descripcion: </strong>{{ $fruta->descripcion }}</p>
    <p><strong>Valoracion: </strong>{{ $fruta->valoracion }}</p>
    <form action="{{ route('frutas.destroy', $fruta) }}" method="post">
        @csrf
        @method('delete')
        <input type="submit" value="Borrar">
    </form>
    <br><a href="{{ route('frutas.index') }}">Volver</a>
@endsection