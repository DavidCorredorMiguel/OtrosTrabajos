@extends('layouts.plantilla')
@section('titulo', 'edit')
@section('contenido')
    <h1>Editar Fruta</h1>
    <form action="{{ route('frutas.update', $fruta) }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $fruta->name) }}">
        @error('name')
            <br><small style="color: red">{{ $message }}</small>
        @enderror
        <br><label>Tipo: </label>
        <input type="text" name="tipo" value="{{ old('tipo', $fruta->tipo) }}">
        @error('tipo')
            <br><small style="color: red">{{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" 
        cols="30" rows="10">{{ old('descripcion', $fruta->descripcion) }}</textarea>
        @error('descripcion')
            <br><small style="color: red">{{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion', $fruta->valoracion) }}">
        @error('valoracion')
            <br><small style="color: red">{{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('frutas.index') }}">Volver</a>
@endsection