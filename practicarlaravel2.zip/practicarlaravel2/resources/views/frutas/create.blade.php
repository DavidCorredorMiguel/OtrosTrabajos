@extends('layouts.plantilla')
@section('titulo', 'create')
@section('contenido')
    <h1>Crear Fruta</h1>
    <form action="{{ route('frutas.store') }}" method="post">
        @csrf
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name') }}">
        @error('name')
            <br><small style="color: red">{{ $message }}</small>
        @enderror
        <br><label>Tipo: </label>
        <input type="text" name="tipo" value="{{ old('tipo') }}">
        @error('tipo')
            <br><small style="color: red">{{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" cols="30" rows="10">{{ old('descripcion') }}</textarea>
        @error('descripcion')
            <br><small style="color: red">{{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion') }}">
        @error('valoracion')
            <br><small style="color: red">{{ $message }}</small>
        @enderror
        <br><input type="submit" value="Crear">
    </form>
    <br><a href="{{ route('frutas.index') }}">Volver</a>
@endsection