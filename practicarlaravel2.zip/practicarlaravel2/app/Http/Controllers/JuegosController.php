<?php

namespace App\Http\Controllers;

use App\Http\Requests\ValidaJuegos;
use App\Models\Juegos;
use Illuminate\Http\Request;

class JuegosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $juegos = Juegos::orderby('id')->paginate();
        return view('juegos.index', compact('juegos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('juegos.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ValidaJuegos $request)
    {
        $juego = Juegos::create($request->all());
        $juego->save();
        return view('juegos.show', compact('juego'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Juegos $juego)
    {
        return view('juegos.show', compact('juego'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Juegos $juego)
    {
        return view('juegos.edit', compact('juego'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ValidaJuegos $request, Juegos $juego)
    {
        $juego->update($request->all());
        $juego->save();
        return view('juegos.show', compact('juego'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Juegos $juego)
    {
        $juego->delete();
        return redirect()->route('juegos.index');
    }
}
