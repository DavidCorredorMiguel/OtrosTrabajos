<?php

namespace App\Http\Controllers;

use App\Http\Requests\ValidaFrutas;
use App\Models\Frutas;
use Illuminate\Http\Request;

class FrutasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $frutas = Frutas::orderby('id')->paginate();
        return view('frutas.index', compact('frutas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('frutas.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ValidaFrutas $request)
    {
        $fruta = Frutas::create($request->all());
        $fruta->save();
        return view('frutas.show', compact('fruta'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Frutas $fruta)
    {
        return view('frutas.show', compact('fruta'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Frutas $fruta)
    {
        return view('frutas.edit', compact('fruta'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ValidaFrutas $request, Frutas $fruta)
    {
        $fruta->update($request->all());
        $fruta->save();
        return view('frutas.show', compact('fruta'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Frutas $fruta)
    {
        $fruta->delete();
        return redirect()->route('frutas.index');
    }
}
