@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Bienvenido</h1>
    <a href="{{ route('cursos.create') }}">Crear Curso</a>
    <ul>
        @foreach ($cursos as $curso)
            <li><a href="{{ route('cursos.show', $curso) }}">{{ $curso->name }}</a></li>
        @endforeach
    </ul>
    {{ $cursos->links() }}
@endsection