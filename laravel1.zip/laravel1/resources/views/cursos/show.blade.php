@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Detalles Curso</h1>
    <a href="{{ route('cursos.edit', $curso) }}">Editar Curso</a>
    <p><strong>Nombre: </strong>{{ $curso->name }}</p>
    <p><strong>Categoria: </strong>{{ $curso->categoria }}</p>
    <p><strong>Descripcion: <</strong>{{ $curso->descripcion }}</p>
    <br><a href="{{ route('cursos.index') }}">Volver</a>
    <form action="{{ route('cursos.destroy', $curso) }}" method="post">
        @csrf
        @method('delete')
        <br><input type="submit" value="Borrar">
    </form>
@endsection