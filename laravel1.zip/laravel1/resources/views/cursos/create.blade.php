@extends('layouts.plantilla')
@section('titulo', 'create')
@section('contenido')
    <h1>Crea Curso</h1>
    <form action="{{ route('cursos.store') }}" method="post">
        @csrf
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name') }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Categoria: </label>
        <input type="text" name="categoria" value="{{ old('categoria') }}">
        @error('categoria')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" cols="30" rows="10">{{ old('descripcion') }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Crear">
    </form>
    <br><a href="{{ route('cursos.index') }}">Volver</a>
@endsection