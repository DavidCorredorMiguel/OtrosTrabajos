@extends('layouts.plantilla')
@section('titulo', 'edit')
@section('contenido')
    <h1>Edita Curso</h1>
    <form action="{{ route('cursos.store') }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $curso->name) }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Categoria: </label>
        <input type="text" name="categoria" value="{{ old('categoria', $curso->categoria) }}">
        @error('categoria')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" cols="30" rows="10">{{ old('descripcion', $curso->descripcion) }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('cursos.index') }}">Volver</a>
@endsection