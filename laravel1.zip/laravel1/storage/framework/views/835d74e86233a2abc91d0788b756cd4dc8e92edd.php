
<?php $__env->startSection('titulo', 'show'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Detalles Curso</h1>
    <a href="<?php echo e(route('cursos.edit', $curso)); ?>">Editar Curso</a>
    <p><strong>Nombre: </strong><?php echo e($curso->name); ?></p>
    <p><strong>Categoria: </strong><?php echo e($curso->categoria); ?></p>
    <p><strong>Descripcion: <</strong><?php echo e($curso->descripcion); ?></p>
    <br><a href="<?php echo e(route('cursos.index')); ?>">Volver</a>
    <form action="<?php echo e(route('cursos.destroy', $curso)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <br><input type="submit" value="Borrar">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\laravel1\resources\views/cursos/show.blade.php ENDPATH**/ ?>