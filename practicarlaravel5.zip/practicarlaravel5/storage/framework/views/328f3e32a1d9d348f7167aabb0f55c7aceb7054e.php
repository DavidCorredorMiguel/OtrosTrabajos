
<?php $__env->startSection('titulo', 'index'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Lista Libros</h1>
    <a href="<?php echo e(route('libros.create')); ?>">Crear Libro</a>
    <ul>
        <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('libros.show', $libro)); ?>"><?php echo e($libro->name); ?> (<?php echo e($libro->genero); ?>)</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($libros->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel5\resources\views/libros/index.blade.php ENDPATH**/ ?>