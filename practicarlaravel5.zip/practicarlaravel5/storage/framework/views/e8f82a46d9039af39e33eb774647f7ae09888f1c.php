
<?php $__env->startSection('titulo', 'show'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Datos Libro</h1>
    <a href="<?php echo e(route('libros.edit', $libro)); ?>">Editar Libro</a>
    <p><strong>Nombre: </strong><?php echo e($libro->name); ?></p>
    <p><strong>Genero: </strong><?php echo e($libro->genero); ?></p>
    <p><strong>Autor: </strong><?php echo e($libro->autor); ?></p>
    <p><strong>Precio: </strong><?php echo e($libro->precio); ?></p>
    <p><strong>Descripcion: </strong><?php echo e($libro->descripcion); ?></p>
    <p><strong>Valoracion: </strong><?php echo e($libro->valoracion); ?></p>
    <form action="<?php echo e(route('libros.destroy', $libro)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <input type="submit" value="Borrar">
    </form>
    <br><a href="<?php echo e(route('libros.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel5\resources\views/libros/show.blade.php ENDPATH**/ ?>