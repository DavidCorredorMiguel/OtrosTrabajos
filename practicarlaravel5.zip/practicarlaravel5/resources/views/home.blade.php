@extends('layouts.plantilla')
@section('titulo', 'home')
@section('contenido')
    <h1>Bienvenido</h1>
    <a href="{{ route('libros.index') }}">Libros</a>
@endsection