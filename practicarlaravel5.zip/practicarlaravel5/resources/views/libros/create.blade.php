@extends('layouts.plantilla')
@section('titulo', 'create')
@section('contenido')
    <h1>Crear Libro</h1>
    <form action="{{ route('libros.store') }}" method="post">
        @csrf
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name') }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Genero: </label>
        <input type="text" name="genero" value="{{ old('genero') }}">
        @error('genero')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Autor: </label>
        <input type="text" name="autor" value="{{ old('autor') }}">
        @error('autor')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Precio: </label>
        <input type="text" name="precio" value="{{ old('precio') }}">
        @error('precio')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" 
        cols="30" rows="10">{{ old('descripcion') }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion') }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Crear">
    </form>
    <br><a href="{{ route('libros.index') }}">Volver</a>
@endsection