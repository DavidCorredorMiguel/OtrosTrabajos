@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Libros</h1>
    <a href="{{ route('libros.create') }}">Crear Libro</a>
    <ul>
        @foreach ($libros as $libro)
            <li><a href="{{ route('libros.show', $libro) }}">{{ $libro->name }} ({{ $libro->genero }})</a></li>
        @endforeach
    </ul>
    {{ $libros->links() }}
@endsection