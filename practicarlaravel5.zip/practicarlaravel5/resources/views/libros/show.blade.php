@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Datos Libro</h1>
    <a href="{{ route('libros.edit', $libro) }}">Editar Libro</a>
    <p><strong>Nombre: </strong>{{ $libro->name }}</p>
    <p><strong>Genero: </strong>{{ $libro->genero }}</p>
    <p><strong>Autor: </strong>{{ $libro->autor }}</p>
    <p><strong>Precio: </strong>{{ $libro->precio }}</p>
    <p><strong>Descripcion: </strong>{{ $libro->descripcion }}</p>
    <p><strong>Valoracion: </strong>{{ $libro->valoracion }}</p>
    <form action="{{ route('libros.destroy', $libro) }}" method="post">
        @csrf
        @method('delete')
        <input type="submit" value="Borrar">
    </form>
    <br><a href="{{ route('libros.index') }}">Volver</a>
@endsection