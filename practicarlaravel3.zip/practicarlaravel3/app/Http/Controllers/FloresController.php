<?php

namespace App\Http\Controllers;

use App\Http\Requests\ValidaFlores;
use App\Models\Flores;
use Illuminate\Http\Request;

class FloresController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $flores = Flores::orderby('id')->paginate();
        return view('flores.index', compact('flores'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('flores.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ValidaFlores $request)
    {
        $flor = Flores::create($request->all());
        $flor->save();
        return view('flores.show', compact('flor'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Flores $flore)
    {
        return view('flores.show', compact('flore'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Flores $flore)
    {
        return view('flores.edit', compact('flore'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ValidaFlores $request, Flores $flore)
    {
        $flore->update($request->all());
        $flore->save();
        return view('flores.show', compact('flore'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Flores $flore)
    {
        $flore->delete();
        return redirect()->route('flores.index');
    }
}
