<?php

namespace App\Http\Controllers;

use App\Http\Requests\ValidaSagas;
use App\Models\Sagas;
use Illuminate\Http\Request;

class SagasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sagas = Sagas::orderby('id')->paginate();
        return view('sagas.index', compact('sagas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('sagas.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ValidaSagas $request)
    {
        $saga = Sagas::create($request->all());
        $saga->save();
        return view('sagas.show', compact('saga'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Sagas $saga)
    {
        return view('sagas.show', compact('saga'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Sagas $saga)
    {
        return view('sagas.edit', compact('saga'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ValidaSagas $request, Sagas $saga)
    {
        $saga->update($request->all());
        $saga->save();
        return view('sagas.show', compact('saga'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sagas $saga)
    {
        $saga->delete();
        return redirect()->route('sagas.index');
    }
}
