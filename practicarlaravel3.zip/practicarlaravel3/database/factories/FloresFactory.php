<?php

namespace Database\Factories;

use App\Models\Flores;
use Illuminate\Database\Eloquent\Factories\Factory;

class FloresFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Flores::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->randomElement(['Rosa','Margarita','Lavanda','Amapola','Lirio',
            'Azucena','Gladiolo']),
            'color' => $this->faker->randomElement(['Rosa','Blanco','Violeta','Azul','Rojo','Verde']),
            'descripcion' => $this->faker->paragraph(),
            'cantidad' => rand(100,10000000),
            'valoracion' => rand(1,10),
        ];
    }
}
