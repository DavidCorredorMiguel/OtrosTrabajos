<?php

namespace Database\Factories;

use App\Models\Sagas;
use Illuminate\Database\Eloquent\Factories\Factory;

class SagasFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Sagas::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->randomElement(['Sonic','One Piece','My Hero Academia','Dragon Ball',
            'Mario Bros','The Legend Of Zelda','Donkey Kong','LEGO','Marvel','DC Comics','Pokemon','Kirby']),
            'tipo' => $this->faker->randomElement(['Pelicula','Serie','Videojuego','Comic','Manga']),
            'descripcion' => $this->faker->paragraph(),
            'anoinicio' => rand(1980,2025),
            'valoracion' => rand(1,10),
        ];
    }
}
