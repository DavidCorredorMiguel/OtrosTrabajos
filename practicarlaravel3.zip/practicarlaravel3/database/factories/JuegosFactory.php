<?php

namespace Database\Factories;

use App\Models\Juegos;
use Illuminate\Database\Eloquent\Factories\Factory;

class JuegosFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Juegos::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            'plataforma' => $this->faker->randomElement(['Switch','Xbox One','PS5','PS4','3DS','DS','New 3DS',
            'Wii U','PSP','PS3','PS2','PS1','Wii','PSVITA','Xbox 360','Xbox']),
            'compania' => $this->faker->randomElement(['SEGA','Nintendo','Sony','Koei Tecmo','Microsoft']),
            'genero' => $this->faker->randomElement(['Accion','Anime','Lucha','ROL','Terror']),
            'descripcion' => $this->faker->paragraph(),
            'valoracion' => rand(1,10),
        ];
    }
}
