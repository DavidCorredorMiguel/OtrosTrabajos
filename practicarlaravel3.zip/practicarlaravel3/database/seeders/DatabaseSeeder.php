<?php

namespace Database\Seeders;

use App\Models\Juegos;
use App\Models\Flores;
use App\Models\Sagas;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
       Juegos::factory(50)->create();
       Flores::factory(50)->create();
       Sagas::factory(50)->create();
    }
}
