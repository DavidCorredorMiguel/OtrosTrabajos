
<?php $__env->startSection('titulo', 'show'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Datos Flor</h1>
    <a href="<?php echo e(route('flores.edit', $flore)); ?>">Editar Flor</a>
    <p><strong>Nombre: </strong><?php echo e($flore->name); ?></p>
    <p><strong>Color: </strong><?php echo e($flore->color); ?></p>
    <p><strong>Descripcion: </strong><?php echo e($flore->descripcion); ?></p>
    <p><strong>Cantidad: </strong><?php echo e($flore->cantidad); ?></p>
    <p><strong>Valoracion: </strong><?php echo e($flore->valoracion); ?></p>
    <form action="<?php echo e(route('flores.destroy', $flore)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <input type="submit" value="Borrar">
    </form>
    <br><a href="<?php echo e(route('flores.index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel3\resources\views/flores/show.blade.php ENDPATH**/ ?>