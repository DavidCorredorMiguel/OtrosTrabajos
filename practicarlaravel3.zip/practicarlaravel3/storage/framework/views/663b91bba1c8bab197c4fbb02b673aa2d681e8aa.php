
<?php $__env->startSection('titulo', 'home'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Bienvenido</h1>
    <a href="<?php echo e(route('juegos.index')); ?>">Juegos</a>
    <br><br><a href="<?php echo e(route('flores.index')); ?>">Flores</a>
    <br><br><a href="<?php echo e(route('sagas.index')); ?>">Sagas</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel3\resources\views/home.blade.php ENDPATH**/ ?>