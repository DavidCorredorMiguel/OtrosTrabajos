
<?php $__env->startSection('titulo', 'index'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1>Lista Flores</h1>
    <a href="<?php echo e(route('flores.create')); ?>">Crear Flores</a>
    <ul>
        <?php $__currentLoopData = $flores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('flores.show', $flor)); ?>"><?php echo e($flor->name); ?> (Color <?php echo e($flor->color); ?>)</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php echo e($flores->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\D.W.E.S\Ejercicios 2ª Evaluación\2 Ejercicios Practicar Laravel\practicarlaravel3\resources\views/flores/index.blade.php ENDPATH**/ ?>