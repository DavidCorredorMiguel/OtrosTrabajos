@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Datos Saga</h1>
    <a href="{{ route('sagas.edit', $saga) }}">Editar Saga</a>
    <p><strong>Nombre: </strong>{{ $saga->name }}</p>
    <p><strong>Tipo: </strong>{{ $saga->tipo }}</p>
    <p><strong>Descripcion: </strong>{{ $saga->descripcion }}</p>
    <p><strong>Año Inicio: </strong>{{ $saga->anoinicio }}</p>
    <p><strong>Valoracion: </strong>{{ $saga->valoracion }}</p>
    <form action="{{ route('sagas.destroy', $saga) }}" method="post">
        @csrf
        @method('delete')
        <input type="submit" value="Borrar">
    </form>
    <br><a href="{{ route('sagas.index') }}">Volver</a>
@endsection