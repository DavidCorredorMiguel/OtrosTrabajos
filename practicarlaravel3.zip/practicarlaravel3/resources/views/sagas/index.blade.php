@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Sagas</h1>
    <a href="{{ route('sagas.create') }}">Crear Saga</a>
    <ul>
        @foreach ($sagas as $saga)
            <li><a href="{{ route('sagas.show', $saga) }}">{{ $saga->name }} ({{ $saga->tipo }} de
                 {{ $saga->anoinicio }})</a></li>
        @endforeach
    </ul>
    {{ $sagas->links() }}
@endsection