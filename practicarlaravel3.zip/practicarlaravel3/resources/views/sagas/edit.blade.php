@extends('layouts.plantilla')
@section('titulo', 'edit')
@section('contenido')
    <h1>Bienvenido</h1>
    <form action="{{ route('sagas.update', $saga) }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $saga->name) }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Tipo: </label>
        <input type="text" name="tipo" value="{{ old('tipo', $saga->tipo) }}">
        @error('tipo')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" 
        cols="30" rows="10">{{ old('descripcion', $saga->descripcion) }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Año Inicio: </label>
        <input type="text" name="anoinicio" value="{{ old('anoinicio', $saga->anoinicio) }}">
        @error('anoinicio')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion', $saga->valoracion) }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('sagas.index') }}">Volver</a>
@endsection