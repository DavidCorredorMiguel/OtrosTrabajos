@extends('layouts.plantilla')
@section('titulo', 'home')
@section('contenido')
    <h1>Bienvenido</h1>
    <a href="{{ route('juegos.index') }}">Juegos</a>
    <br><br><a href="{{ route('flores.index') }}">Flores</a>
    <br><br><a href="{{ route('sagas.index') }}">Sagas</a>
@endsection