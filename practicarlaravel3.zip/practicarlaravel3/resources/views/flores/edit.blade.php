@extends('layouts.plantilla')
@section('titulo', 'edit')
@section('contenido')
    <h1>Bienvenido</h1>
    <form action="{{ route('flores.update', $flore) }}" method="post">
        @csrf
        @method('put')
        <label>Nombre: </label>
        <input type="text" name="name" value="{{ old('name', $flore->name) }}">
        @error('name')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Color: </label>
        <input type="text" name="color" value="{{ old('color', $flore->color) }}">
        @error('color')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Descripcion: </label><br>
        <textarea name="descripcion" 
        cols="30" rows="10">{{ old('descripcion', $flore->descripcion) }}</textarea>
        @error('descripcion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Cantidad: </label>
        <input type="text" name="cantidad" value="{{ old('cantidad', $flore->cantidad) }}">
        @error('cantidad')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><label>Valoracion: </label>
        <input type="text" name="valoracion" value="{{ old('valoracion', $flore->valoracion) }}">
        @error('valoracion')
            <br><small style="color: red">* {{ $message }}</small>
        @enderror
        <br><br><input type="submit" value="Actualizar">
    </form>
    <br><a href="{{ route('flores.index') }}">Volver</a>
@endsection