@extends('layouts.plantilla')
@section('titulo', 'show')
@section('contenido')
    <h1>Datos Flor</h1>
    <a href="{{ route('flores.edit', $flore) }}">Editar Flor</a>
    <p><strong>Nombre: </strong>{{ $flore->name }}</p>
    <p><strong>Color: </strong>{{ $flore->color }}</p>
    <p><strong>Descripcion: </strong>{{ $flore->descripcion }}</p>
    <p><strong>Cantidad: </strong>{{ $flore->cantidad }}</p>
    <p><strong>Valoracion: </strong>{{ $flore->valoracion }}</p>
    <form action="{{ route('flores.destroy', $flore) }}" method="post">
        @csrf
        @method('delete')
        <input type="submit" value="Borrar">
    </form>
    <br><a href="{{ route('flores.index') }}">Volver</a>
@endsection