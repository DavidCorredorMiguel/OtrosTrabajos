@extends('layouts.plantilla')
@section('titulo', 'index')
@section('contenido')
    <h1>Lista Flores</h1>
    <a href="{{ route('flores.create') }}">Crear Flores</a>
    <ul>
        @foreach ($flores as $flor)
            <li><a href="{{ route('flores.show', $flor) }}">{{ $flor->name }} (Color {{ $flor->color }})</a></li>
        @endforeach
    </ul>
    {{ $flores->links() }}
@endsection